from django.db import models
from pathlib import Path
from uuid import uuid4

from equipe.models import Equipe, EquipeMembro
from praia.models import Praia
from usuario.models import Usuario, Voluntario


def caminho_imagem_acao(instance, filename):
    """Define o path de upload de imagens organizado por ano/mês da ação.
    Ex: acoes/2025/03/acao-42/a1b2c3d4.jpg"""
    extensao = Path(filename).suffix.lower()
    nome_unico = f'{uuid4().hex}{extensao}'
    return (
        f'acoes/{instance.acao.data.year}/'
        f'{instance.acao.data.month:02d}/'
        f'acao-{instance.acao_id}/{nome_unico}'
    )


class Acao(models.Model):
    """
    Ação de limpeza de praia (mutirão ou coleta voluntária).
    
    managed=False: tabela criada manualmente no SQLite (não via migrations).
    O MongoDB é a fonte de leitura das telas, mas o SQLite gera o ID auto-increment.
    Properties com import tardio (coletas_residuos, movimentacoes_estoque) evitam
    import circular entre os apps acao <-> residuo <-> estoque.
    """
    @property
    def movimentacoes_estoque(self):
        from estoque.models import MovimentacaoEstoque
        return MovimentacaoEstoque.objects.filter(acao_id=self.pk)

    @property
    def coletas_residuos(self):
        from residuo.models import ColetaResiduo
        return ColetaResiduo.objects.filter(acao_id=self.pk)

    @property
    def residuos_coletados(self):
        from residuo.models import ResiduoColetado
        return ResiduoColetado.objects.filter(acao_id=self.pk)

    TIPO_MUTIRAO = 'MUTIRAO'
    TIPO_COLETA_VOLUNTARIA = 'COLETA_VOLUNTARIA'
    TIPO_CHOICES = [
        (TIPO_MUTIRAO, 'Mutirão'),
        (TIPO_COLETA_VOLUNTARIA, 'Coleta voluntária'),
    ]

    STATUS_PLANEJADA = 'PLANEJADA'
    STATUS_EM_ANDAMENTO = 'EM_ANDAMENTO'
    STATUS_CONCLUIDA = 'CONCLUIDA'
    STATUS_CANCELADA = 'CANCELADA'
    STATUS_CHOICES = [
        (STATUS_PLANEJADA, 'Planejada'),
        (STATUS_EM_ANDAMENTO, 'Em andamento'),
        (STATUS_CONCLUIDA, 'Concluída'),
        (STATUS_CANCELADA, 'Cancelada'),
    ]

    id_acao = models.AutoField(primary_key=True)
    tipo = models.CharField(max_length=30, choices=TIPO_CHOICES)
    data = models.DateField()
    horario = models.TimeField(blank=True, null=True)
    local = models.CharField(max_length=255, blank=True, default='')
    descricao = models.TextField(blank=True, default='')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PLANEJADA)
    imagens = models.JSONField(default=list, blank=True)
    praia = models.ForeignKey(Praia, on_delete=models.DO_NOTHING, db_constraint=False, related_name='acoes')
    dt_cadastro = models.DateTimeField(auto_now_add=True)
    cadastrado_por = models.ForeignKey(
        Usuario,
        on_delete=models.DO_NOTHING,
        db_constraint=False,
        null=True,
        blank=True,
        related_name='acoes_cadastradas',
    )
    cadastrado_por_nome = models.CharField(max_length=150, null=True, blank=True)
    cadastrado_por_tipo = models.CharField(max_length=20, null=True, blank=True)
    dt_ultima_edicao = models.DateTimeField(null=True, blank=True)
    ultimo_editado_por = models.ForeignKey(
        Usuario,
        on_delete=models.DO_NOTHING,
        db_constraint=False,
        null=True,
        blank=True,
        related_name='acoes_editadas',
    )
    ultimo_editado_por_nome = models.CharField(max_length=150, null=True, blank=True)
    ultimo_editado_por_tipo = models.CharField(max_length=20, null=True, blank=True)

    class Meta:
        managed = False
        db_table = 'acao'
        verbose_name = 'Ação'
        verbose_name_plural = 'Ações'
        ordering = ('-data', 'horario')

    def __str__(self):
        return f'{self.get_tipo_display()} - {self.praia} - {self.data}'


class AcaoImagem(models.Model):
    id_acao_imagem = models.AutoField(primary_key=True)
    acao = models.ForeignKey(
        Acao,
        on_delete=models.CASCADE,
        related_name='imagens_acao',
    )
    imagem = models.ImageField(upload_to=caminho_imagem_acao)
    descricao = models.CharField(max_length=255, blank=True)
    dt_cadastro = models.DateTimeField(auto_now_add=True)

    class Meta:
        managed = False
        db_table = 'acao_imagem'
        verbose_name = 'Imagem da ação'
        verbose_name_plural = 'Imagens da ação'
        ordering = ('-dt_cadastro',)

    def __str__(self):
        return f'Imagem da ação {self.acao_id}'


class AcaoEquipe(models.Model):
    id_acao_equipe = models.AutoField(primary_key=True)
    acao = models.ForeignKey(Acao, on_delete=models.CASCADE, related_name='equipes_vinculadas')
    equipe = models.ForeignKey(Equipe, on_delete=models.DO_NOTHING, db_constraint=False, related_name='acoes_vinculadas')

    class Meta:
        managed = False
        db_table = 'acao_equipe'
        verbose_name = 'Equipe da ação'
        verbose_name_plural = 'Equipes da ação'
        unique_together = ('acao', 'equipe')

    def __str__(self):
        return f'{self.acao} / {self.equipe}'


class AcaoParticipante(models.Model):
    STATUS_PENDENTE = 'PENDENTE'
    STATUS_CONFIRMADO = 'CONFIRMADO'
    STATUS_RECUSADO = 'RECUSADO'
    STATUS_PRESENTE = 'PRESENTE'
    STATUS_NAO_COMPARECEU = 'NAO_COMPARECEU'
    STATUS_CHOICES = [
        (STATUS_PENDENTE, 'Pendente'),
        (STATUS_CONFIRMADO, 'Confirmado'),
        (STATUS_RECUSADO, 'Recusado'),
        (STATUS_PRESENTE, 'Presente'),
        (STATUS_NAO_COMPARECEU, 'Não compareceu'),
    ]

    id_acao_participante = models.AutoField(primary_key=True)
    acao = models.ForeignKey(Acao, on_delete=models.CASCADE, related_name='participantes')
    voluntario = models.ForeignKey(Voluntario, on_delete=models.DO_NOTHING, db_constraint=False, related_name='acoes_participadas')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PENDENTE)
    compareceu = models.BooleanField(default=False)
    observacao = models.TextField(blank=True, default='')
    dt_confirmacao = models.DateTimeField(null=True, blank=True)
    dt_cadastro = models.DateTimeField(auto_now_add=True)

    class Meta:
        managed = False
        db_table = 'acao_participante'
        verbose_name = 'Participante da ação'
        verbose_name_plural = 'Participantes da ação'
        unique_together = ('acao', 'voluntario')

    def __str__(self):
        return f'{self.voluntario.nome} - {self.acao}'


class AcaoParticipanteHistorico(models.Model):
    """
    Histórico de participantes removidos de uma ação (soft delete).
    
    Quando um participante é recusado ou não comparece, em vez de deletar o registro,
    ele é movido para este histórico. Isso preserva o rastro de quem participou/ não
    participou para cálculo de frequência. O campo 'restaurado' permite reverter.
    """
    id_historico = models.AutoField(primary_key=True)
    acao = models.ForeignKey(
        Acao,
        on_delete=models.CASCADE,
        related_name='historico_participantes',
    )
    voluntario = models.ForeignKey(
        Voluntario,
        on_delete=models.PROTECT,
        related_name='historico_acoes_participadas',
    )
    status = models.CharField(max_length=20, choices=AcaoParticipante.STATUS_CHOICES)
    compareceu = models.BooleanField(default=False)
    observacao = models.TextField(blank=True, default='')
    dt_cadastro = models.DateTimeField()
    dt_movimentacao = models.DateTimeField(auto_now_add=True)
    movido_por = models.ForeignKey(
        Usuario,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='historicos_participantes_movidos',
    )
    movido_por_nome = models.CharField(max_length=150, null=True, blank=True)
    movido_por_tipo = models.CharField(max_length=20, null=True, blank=True)
    restaurado = models.BooleanField(default=False)
    restaurado_em = models.DateTimeField(null=True, blank=True)
    restaurado_por = models.ForeignKey(
        Usuario,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='historicos_participantes_restaurados',
    )
    restaurado_por_nome = models.CharField(max_length=150, null=True, blank=True)
    restaurado_por_tipo = models.CharField(max_length=20, null=True, blank=True)

    class Meta:
        managed = False
        db_table = 'acao_participante_historico'
        verbose_name = 'Histórico de participante da ação'
        verbose_name_plural = 'Histórico de participantes da ação'
        ordering = ('-dt_movimentacao', 'voluntario__nome')

    def __str__(self):
        return f'{self.voluntario.nome} - {self.acao} ({self.get_status_display()})'


class AcaoResponsavel(models.Model):
    PAPEL_COORDENADOR = 'COORDENADOR'
    PAPEL_RESPONSAVEL = 'RESPONSAVEL'
    PAPEL_CHOICES = [
        (PAPEL_COORDENADOR, 'Coordenador'),
        (PAPEL_RESPONSAVEL, 'Responsável'),
    ]

    id_acao_responsavel = models.AutoField(primary_key=True)
    acao = models.ForeignKey(Acao, on_delete=models.CASCADE, related_name='responsaveis')
    voluntario = models.ForeignKey(Voluntario, on_delete=models.DO_NOTHING, db_constraint=False, related_name='acoes_responsavel')
    papel = models.CharField(max_length=20, choices=PAPEL_CHOICES, default=PAPEL_RESPONSAVEL)

    class Meta:
        managed = False
        db_table = 'acao_responsavel'
        verbose_name = 'Responsável pela ação'
        verbose_name_plural = 'Responsáveis pela ação'
        unique_together = ('acao', 'voluntario')

    def __str__(self):
        return f'{self.voluntario.nome} - {self.acao}'


def adicionar_coordenadores_automaticos_para_mutirao(acao):
    """Vincula automaticamente os coordenadores das equipes da praia como responsáveis da ação.
    Só executa para ações do tipo MUTIRAO (que são as que envolvem equipes)."""
    if acao.tipo != Acao.TIPO_MUTIRAO:
        return []

    coordenadores = (
        acao.equipes_vinculadas
        .filter(equipe__status='ATIVA')
        .values_list('equipe_id', flat=True)
    )
    membros = EquipeMembro.objects.filter(
        equipe_id__in=coordenadores,
        papel=EquipeMembro.PAPEL_COORDENADOR,
        status='ATIVO',
    )

    responsaveis = []
    for membro in membros:
        responsavel, _ = AcaoResponsavel.objects.get_or_create(
            acao=acao,
            voluntario_id=membro.voluntario_id,
            defaults={'papel': AcaoResponsavel.PAPEL_COORDENADOR},
        )
        if responsavel.papel != AcaoResponsavel.PAPEL_COORDENADOR:
            responsavel.papel = AcaoResponsavel.PAPEL_COORDENADOR
            responsavel.save(update_fields=['papel'])
        responsaveis.append(responsavel)

    return responsaveis


def adicionar_participantes_automaticos_para_mutirao(acao):
    """Inscreve automaticamente todos os membros ativos das equipes vinculadas à praia.
    Evita cadastro manual de dezenas de voluntários quando o mutirão já tem equipes definidas."""
    if acao.tipo != Acao.TIPO_MUTIRAO:
        return []

    voluntarios_automaticos = set()
    for vinculada in acao.equipes_vinculadas.select_related('equipe__praia'):
        membros = vinculada.equipe.membros.select_related('voluntario').filter(status='ATIVO')
        for membro in membros:
            voluntarios_automaticos.add(membro.voluntario_id)

    cadastrados = []
    for voluntario_id in sorted(voluntarios_automaticos):
        participante, created = AcaoParticipante.objects.get_or_create(
            acao=acao,
            voluntario_id=voluntario_id,
            defaults={'status': AcaoParticipante.STATUS_PENDENTE},
        )
        if created:
            participante.status = AcaoParticipante.STATUS_PENDENTE
            participante.save(update_fields=['status'])
        cadastrados.append(participante)

    return cadastrados
