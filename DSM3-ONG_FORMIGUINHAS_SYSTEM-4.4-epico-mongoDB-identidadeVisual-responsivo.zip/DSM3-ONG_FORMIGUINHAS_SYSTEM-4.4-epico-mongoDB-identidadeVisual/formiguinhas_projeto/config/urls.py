"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    path('usuario/', include('usuario.urls')),
    path('praia/', include('praia.urls')),
    path('equipe/', include('equipe.urls')),
    path('acao/', include('acao.urls')),
    path('residuo/', include('residuo.urls')),
    path('condominio/', include('condominio.urls')),
    path('auditoria/', include('auditoria.urls')),
    path('comunicado/', include('comunicado.urls')),
    path('doacao/', include('doacao.urls')),
    path('estoque/', include('estoque.urls')),
    path('relatorios/', include('relatorios.urls')),
    path('', include('site_institucional.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
