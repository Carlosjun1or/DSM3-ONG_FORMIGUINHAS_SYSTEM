@echo off
setlocal
title Formiguinhas - Inicializacao

set "ROOT_DIR=%~dp0"
set "PROJECT_DIR=%ROOT_DIR%formiguinhas_projeto"

if not exist "%PROJECT_DIR%\manage.py" (
    echo ERRO: nao foi encontrada a pasta do projeto em:
    echo %PROJECT_DIR%
    pause
    exit /b 1
)

where python >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=python"
) else (
    where py >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_CMD=py -3"
    ) else (
        echo ERRO: Python nao foi encontrado no computador.
        echo Instale o Python e marque a opcao "Add Python to PATH".
        pause
        exit /b 1
    )
)

cd /d "%PROJECT_DIR%"

if not exist "venv\Scripts\python.exe" (
    echo Criando ambiente virtual...
    %PYTHON_CMD% -m venv venv
    if errorlevel 1 goto :erro
)

echo Instalando dependencias do sistema e do MongoDB Atlas...
"%CD%\venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto :erro

if exist "testar_atlas.py" (
    echo.
    echo Verificando integracao com o MongoDB Atlas...
    "%CD%\venv\Scripts\python.exe" testar_atlas.py
    echo.
)

echo Gerando migracoes pendentes...
"%CD%\venv\Scripts\python.exe" manage.py makemigrations
if errorlevel 1 goto :erro

echo Atualizando banco de dados relacional (SQLite)...
"%CD%\venv\Scripts\python.exe" manage.py migrate
if errorlevel 1 goto :erro

set "PORT=8000"
:procurar_porta
netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul
if not errorlevel 1 (
    echo A porta %PORT% ja esta em uso. Procurando outra porta...
    set /a PORT+=1
    goto :procurar_porta
)

echo Iniciando sistema...
echo Acesse http://127.0.0.1:%PORT%/
"%CD%\venv\Scripts\python.exe" manage.py runserver 127.0.0.1:%PORT%
if errorlevel 1 goto :erro

endlocal
exit /b 0

:erro
echo.
echo O sistema nao foi iniciado. Verifique a mensagem acima.
pause
endlocal
exit /b 1
